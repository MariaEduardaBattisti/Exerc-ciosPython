# faça um Programa que peça um número inteiro e determine se ele é par ou impar.#
# Dica: utilize o operador módulo (resto da divisão)#

num = int(input("Olá! Insira um número: "))

if (num%2) == 0:
    print('O número é par.')
else:
    print('O numero é impar.')