num = float(input("Insira um número: "))
num2 = float(input("Insira o segundo número: "))

operacao = input("Informe a operação desejada: / para divisão, * para multiplicação, + para soma, - para subtração. ")

if operacao == "/":
    resultado = num / num2
    print(num, " / ", num2, " = ", resultado)
    if resultado < 0:
        print("o número é negativo.")
    else:
        print("o número é positivo.")
    if (resultado % 2) == 0:
        print('O número é par.')
    else:
        print('O numero é impar.')
    if resultado == round(resultado):
        print("Inteiro")
    else:
        print("Decimal")

if operacao == "*":
    resultado = num * num2
    print(num, " * ", num2, " = ", resultado)
    if resultado < 0:
        print("o número é negativo.")
    else:
        print("o número é positivo.")
    if (resultado % 2) == 0:
        print('O número é par.')
    else:
        print('O numero é impar.')
    if resultado == round(resultado):
        print("Inteiro")
    else:
        print("Decimal")

if operacao == "+":
    resultado = num + num2
    print(num, " + ", num2, " = ", resultado)
    if resultado < 0:
        print("o número é negativo.")
    else:
        print("o número é positivo.")
    if (resultado % 2) == 0:
        print('O número é par.')
    else:
        print('O numero é impar.')
    if resultado == round(resultado):
        print("Inteiro")
    else:
        print("Decimal")

if operacao == "-":
    resultado = num - num2
    print(num, " - ", num2, " = ", resultado)
    if resultado < 0:
        print("o número é negativo.")
    else:
        print("o número é positivo.")
    if (resultado % 2) == 0:
        print('O número é par.')
    else:
        print('O numero é impar.')
    if resultado == round(resultado):
        print("Inteiro")
    else:
        print("Decimal")