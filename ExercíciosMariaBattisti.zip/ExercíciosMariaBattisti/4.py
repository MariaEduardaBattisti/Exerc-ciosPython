print("Por gentileza, responda 1 para SIM e 0 para NAO")
perg1= int(input("Telefonou para a vítima? "))
perg2= int(input("Esteve no local do crime? "))
perg3= int(input("Mora perto da vítima?"))
perg4= int(input("Devia para a vítima? "))
perg5= int(input("Já trabalhou com a vítima?"))

soma = perg1 + perg2 + perg3 + perg4 + perg5

if soma < 2:
    print("Inocente.")
if soma == 2:
    print("Suspeito.")
if soma < 4:
    print("Cúmplice.")
if soma >= 4:
    print("Culpado.")